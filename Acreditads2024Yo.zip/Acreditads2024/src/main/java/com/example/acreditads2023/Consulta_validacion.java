package com.example.acreditads2023;

public class Consulta_validacion {

    private final String clave = "a3fe4cb822574d5eb3dd4089a9d9f801";
    private String email;

    public Consulta_validacion (){

    }

    public String getClave() {
        return clave;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
