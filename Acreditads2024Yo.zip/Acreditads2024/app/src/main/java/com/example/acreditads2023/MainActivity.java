package com.example.acreditads2023;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
public class MainActivity extends AppCompatActivity {
    private Button btnAgenda,btnRegistro,btnAdministracion,btnAcreditacion,btnMiActividad;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAgenda = findViewById(R.id.btnAgenda);
        btnAgenda.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), Agenda_activity.class);
            startActivity(intent);
        });

        btnRegistro = findViewById(R.id.btnRegistro);
        btnRegistro.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), Usuario_activity.class);
            startActivity(intent);
        });

        btnAdministracion = findViewById(R.id.btnAdministracion);
        btnAdministracion.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), AccesoAdministradores.class);
            startActivity(intent);
        });

        btnAcreditacion = findViewById(R.id.btnAcreditacion);
        btnAcreditacion.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), Acreditaciones_activity.class);
            startActivity(intent);
        });

        btnMiActividad = findViewById(R.id.btnMiActividad);
        btnMiActividad.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), Consulta_id.class);
            startActivity(intent);
        });
    }
}