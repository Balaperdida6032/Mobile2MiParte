package com.example.acreditads2023;

public class AccesoAdm_activity {
    //comparar clave introducida con BD y conducir a registro de eventos
    //guardar tareaUsuario en BD
}
