package com.example.acreditads2023;

public class AccesoAdministradoresDAO {
    private Database db;
    private String claveAdm;
    private String tareaUsuario;
}
