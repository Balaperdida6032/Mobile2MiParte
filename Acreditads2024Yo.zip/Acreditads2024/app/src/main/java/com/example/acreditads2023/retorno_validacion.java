package com.example.acreditads2023;

public class retorno_validacion {

    private String address,status;
    public retorno_validacion(){}

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
